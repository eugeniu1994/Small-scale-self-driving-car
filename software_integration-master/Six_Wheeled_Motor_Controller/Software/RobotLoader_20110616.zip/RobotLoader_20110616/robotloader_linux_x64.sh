#!/bin/bash
#

java -Djava.library.path="./lib/linux_x64" -jar RobotLoader_lib.jar

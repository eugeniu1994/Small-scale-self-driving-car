#!/bin/bash
#

java -Xmx256m -Djava.library.path="./lib/linux_x64" -jar RobotLoader_lib.jar
